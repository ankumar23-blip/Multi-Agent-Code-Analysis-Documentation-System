Streamlit dashboard for controlling and monitoring jobs.
- Set API_URL to FastAPI backend.
- Provides Start / Pause / Resume and shows mermaid flow.
