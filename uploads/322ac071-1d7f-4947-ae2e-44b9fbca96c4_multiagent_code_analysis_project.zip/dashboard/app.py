import os
import streamlit as st
import httpx
API_URL = os.getenv('API_URL','http://localhost:8000')

st.set_page_config(page_title='Multi-Agent Dashboard', layout='wide')

st.title('Multi-Agent Code Analysis — Control Panel')

with st.sidebar:
    role = st.selectbox('Role', ['user','admin'])
    repo = st.text_input('Repository URL', 'https://github.com/example/repo')
    if st.button('Start Analysis'):
        resp = httpx.post(f'{API_URL}/api/start-analysis', json={'repository_url': repo, 'options':{}})
        st.session_state['job_id'] = resp.json().get('job_id')

job_id = st.session_state.get('job_id')
if job_id:
    st.write('Job ID:', job_id)
    col1, col2 = st.columns([2,1])
    with col2:
        if st.button('Pause'):
            httpx.post(f'{API_URL}/api/control/{job_id}/pause')
        if st.button('Resume'):
            httpx.post(f'{API_URL}/api/control/{job_id}/resume')
    with col1:
        status = httpx.get(f'{API_URL}/api/jobs/{job_id}/status').json()
        st.metric('Status', status.get('status'))
        st.progress(int(status.get('progress',0)*100))
        mermaid_resp = httpx.get(f'{API_URL}/api/docs/{job_id}/mermaid').json()
        mermaid = mermaid_resp.get('mermaid','')
        if mermaid:
            st.markdown('### Generated Flow (Mermaid)')
            st.code(mermaid, language='mermaid')
