import os
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql+asyncpg://postgres:postgres@db:5432/code_analysis')

engine = create_async_engine(DATABASE_URL, echo=False)
async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def init_db():
    # For dev: run init SQL if exists
    sql_path = '/app/infra/init_db.sql'
    if os.path.exists(sql_path):
        import asyncpg
        # connect and execute file (sync for simplicity)
        with open(sql_path, 'r') as f:
            sql = f.read()
        # use asyncpg to execute raw SQL
        conn = await asyncpg.connect(dsn=DATABASE_URL.replace('+asyncpg',''))
        await conn.execute(sql)
        await conn.close()
