from fastapi import APIRouter, Depends, HTTPException
from .schemas import *
from .auth import require_role
from .workers.orchestrator import Orchestrator

router = APIRouter()

@router.post('/start-analysis', response_model=AnalysisStartResponse)
async def start_analysis(payload: AnalysisStartRequest, orchestrator: Orchestrator = Depends(lambda: None)):
    # orchestrator will be attached to app.state in main
    from fastapi import Request
    import fastapi
    req: Request = fastapi.Request(scope=None)  # placeholder
    orch = fastapi.current_app.state.orchestrator
    job_id = await orch.start_job(payload.repository_url, payload.options)
    return {"job_id": job_id}

@router.post('/control/{job_id}/pause')
async def pause_job(job_id: str):
    orch = fastapi.current_app.state.orchestrator
    await orch.pause(job_id)
    return {"status": "paused"}

@router.post('/control/{job_id}/resume')
async def resume_job(job_id: str):
    orch = fastapi.current_app.state.orchestrator
    await orch.resume(job_id)
    return {"status": "resumed"}

@router.get('/jobs/{job_id}/status')
async def job_status(job_id: str):
    orch = fastapi.current_app.state.orchestrator
    return await orch.status(job_id)

@router.get('/docs/{job_id}/mermaid')
async def get_mermaid(job_id: str):
    orch = fastapi.current_app.state.orchestrator
    return {"mermaid": await orch.get_mermaid(job_id)}
