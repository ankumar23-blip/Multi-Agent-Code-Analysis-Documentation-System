from pydantic import BaseModel
from typing import Dict, Any

class AnalysisStartRequest(BaseModel):
    repository_url: str
    options: Dict[str, Any] = {}

class AnalysisStartResponse(BaseModel):
    job_id: str

class JobStatus(BaseModel):
    job_id: str
    status: str
    progress: float
    details: Dict[str, Any] = {}
