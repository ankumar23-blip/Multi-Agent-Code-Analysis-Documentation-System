import os
import openai

OPENAI_KEY = os.getenv('OPENAI_API_KEY')
openai.api_key = OPENAI_KEY

def embed_text(text):
    # placeholder embedding call
    # return a list of floats representing embedding
    # In production: call openai.Embedding.create(...) or your chosen provider.
    return [0.0]*1536
